import { useState, useCallback } from "react";

// ─── BACKEND CONFIG ───────────────────────────────────────────────────────────
// After deploying to Railway, replace this with your Railway URL.
// Example: "https://kc-housing-intel-backend-production.up.railway.app"
const BACKEND_URL = "https://YOUR-RAILWAY-URL.up.railway.app";

// ─── constants ────────────────────────────────────────────────────────────────

const SEARCH_CONFIGS = [
  { id: "kcdata",   label: "KC Open Data",       icon: "KC", color: "#1565C0", description: "Live KC property violations — EnerGov, updated daily" },
  { id: "hud",      label: "HUD / Section 8",    icon: "H",  color: "#2E7D32", description: "HUD Multifamily Assisted Housing database" },
];

const KEYWORDS = [
  "mold","rats","mice","roaches","bedbugs","bed bugs","infestation","insects",
  "pest","black mold","flooding","no heat","no hot water","sewage","habitability",
  "unsafe","uninhabitable","section 8","HUD","voucher","landlord ignored",
  "maintenance ignored","health violation","code violation","retaliation","slumlord","eviction threat",
];

const sizeLabel = (units) => {
  if (!units)       return { label: "UNKNOWN",  color: "#555"    };
  if (units >= 200) return { label: "LARGE",    color: "#C62828" };
  if (units >= 100) return { label: "MID-SIZE", color: "#FF6D00" };
  if (units >= 50)  return { label: "MEDIUM",   color: "#FFD600" };
  return              { label: "SMALL",    color: "#69F0AE" };
};

const severityConfig = {
  critical: { label: "CRITICAL", bg: "#FF1744", text: "#fff" },
  high:     { label: "HIGH",     bg: "#FF6D00", text: "#fff" },
  medium:   { label: "MEDIUM",   bg: "#FFD600", text: "#000" },
  low:      { label: "LOW",      bg: "#69F0AE", text: "#000" },
};

const sourceColors = {
  kcdata: "#1565C0", hud: "#2E7D32",
};

// HUD subsidy status: "unverified" | "confirmed" | "not_found" | "checking"
const sec8Config = {
  confirmed:   { label: "HUD CONFIRMED",   bg: "#1a4a1a", border: "#2E7D32", color: "#69F0AE", icon: "✓" },
  not_found:   { label: "NOT IN HUD DB",   bg: "#1a1a1a", border: "#444",    color: "#777",    icon: "–" },
  unverified:  { label: "UNVERIFIED",      bg: "#2a1a00", border: "#7a4a00", color: "#FFD600", icon: "?" },
  checking:    { label: "CHECKING HUD…",   bg: "#0a1a2a", border: "#1a4a6a", color: "#4499cc", icon: "↻" },
};

// ─── sample complaint data (section8Status starts as "unverified") ────────────

const INITIAL_COMPLAINTS = [
  {
    id: 1, source: "reddit", platform: "Reddit – r/kansascity", date: "2024-11-14",
    complex: "Westport Gardens Apartments",
    address: "3900 Broadway Blvd, Kansas City, MO 64111",
    managementCompany: "Millennia Housing Management",
    managementWebsite: "https://www.millenniahousing.com",
    totalUnits: 312, yearBuilt: 1974,
    section8Status: "unverified", hudMatch: null,
    tags: ["mold", "maintenance ignored", "no heat"], severity: "high",
    text: "Been dealing with black mold in my bathroom for 8 months. Maintenance keeps marking tickets 'resolved' without coming out. Three other families on my floor have the same issue. Management won't return calls. This is a Section 8 property.",
    contact: "u/kc_renter_2024",
    url: "https://www.reddit.com/r/kansascity/comments/1gx8m4t/anyone_else_dealing_with_westport_gardens_mold/",
    potentialContacts: 4,
  },
  {
    id: 2, source: "google", platform: "Google Maps Reviews", date: "2024-10-28",
    complex: "Riverside Park Apartments",
    address: "1201 Riverside Dr, Kansas City, MO 64150",
    managementCompany: "Block Real Estate Services",
    managementWebsite: "https://www.blockllc.com",
    totalUnits: 228, yearBuilt: 1968,
    section8Status: "unverified", hudMatch: null,
    tags: ["rats", "roaches", "sewage"], severity: "high",
    text: "Rats in the walls for over a year. Management has been notified multiple times in writing. The entire building has this problem — I've talked to 6 other tenants who submitted complaints. Sewage backup in unit 4B flooded into hallway.",
    contact: "Google Review — Jamie T.",
    url: "https://maps.google.com/?cid=12983746502938471",
    potentialContacts: 6,
  },
  {
    id: 3, source: "hud", platform: "HUD Complaint Portal", date: "2024-12-01",
    complex: "Heritage Pointe Residences",
    address: "7800 Troost Ave, Kansas City, MO 64131",
    managementCompany: "NRP Group / Affordable Communities",
    managementWebsite: "https://www.nrpgroup.com",
    totalUnits: 184, yearBuilt: 1989,
    section8Status: "unverified", hudMatch: null,
    tags: ["black mold", "no hot water", "habitability"], severity: "critical",
    text: "HUD complaint filed: Widespread black mold in units 101–108. Hot water has been out building-wide for 11 days. Health inspector cited property in September. Owner has not remediated. Approximately 14 households affected.",
    contact: "HUD Case #MO-2024-08812",
    url: "https://www.hud.gov/program_offices/fair_housing_equal_opp/online-complaint",
    potentialContacts: 14,
  },
  {
    id: 4, source: "facebook", platform: "Facebook – KC Renters Group", date: "2024-11-05",
    complex: "Meadowbrook Manor",
    address: "5500 E 63rd St, Kansas City, MO 64130",
    managementCompany: "Sullivan Property Management",
    managementWebsite: "https://www.sullivanpm.com",
    totalUnits: 96, yearBuilt: 1981,
    section8Status: "unverified", hudMatch: null,
    tags: ["bed bugs", "infestation", "retaliation"], severity: "high",
    text: "Bed bug infestation has spread through most of the building. When I complained, they sent me a lease violation notice. Other residents have commented — looks like at least 8 units affected. Anyone else dealing with this at Meadowbrook?",
    contact: "FB Post — Denise R.",
    url: "https://www.facebook.com/groups/kansascityrenters/posts/8812937461029384/",
    potentialContacts: 8,
  },
  {
    id: 5, source: "yelp", platform: "Yelp Reviews", date: "2024-09-18",
    complex: "Creekside Commons",
    address: "2200 N Oak Trafficway, Kansas City, MO 64116",
    managementCompany: "Yarco Company",
    managementWebsite: "https://www.yarco.com",
    totalUnits: 64, yearBuilt: 1992,
    section8Status: "unverified", hudMatch: null,
    tags: ["mold", "flooding", "code violation"], severity: "medium",
    text: "Water intrusion every time it rains. Mold growing on every exterior wall. City inspector came out and gave them a violation. Management promised to fix it 4 months ago — still nothing. Multiple residents left reviews with the same story.",
    contact: "Yelp Review — Marcus D.",
    url: "https://www.yelp.com/biz/creekside-commons-kansas-city",
    potentialContacts: 3,
  },
  {
    id: 6, source: "bbb", platform: "BBB Complaints", date: "2025-01-10",
    complex: "Colony Square Apartments",
    address: "9300 E 47th St, Kansas City, MO 64133",
    managementCompany: "Wingate Management Co.",
    managementWebsite: "https://www.wingatemanagement.com",
    totalUnits: 420, yearBuilt: 1971,
    section8Status: "unverified", hudMatch: null,
    tags: ["rats", "no heat", "code violation", "retaliation"], severity: "critical",
    text: "Three separate BBB complaints filed in 90 days. Rats visible in common areas, broken heating system across entire building during winter, management threatened non-renewal when tenants complained to city inspectors. City has issued formal notice of violation.",
    contact: "BBB Complaint #KC-2025-00441",
    url: "https://www.bbb.org/us/mo/kansas-city/profile/apartments/wingate-management-0816-233819",
    potentialContacts: 11,
  },
];

// ─── HUD API helpers ───────────────────────────────────────────────────────────

/**
 * Query HUD's public Multifamily Housing dataset for a KC address.
 * Endpoint: https://data.hud.gov/Housing_Counselor/searchHousingCounselor  (no key needed)
 * For property subsidy lookup we use the HUD USPS Crosswalk / Multifamily properties API.
 *
 * Real endpoint: GET https://api.hud.gov/hudapi/public/multifamily/properties?state=MO&city=KANSAS+CITY
 * Requires free HUD API key at https://www.huduser.gov/portal/dataset/api-registration.html
 *
 * For this tool we use the *public* HUD Affordable Housing Locator dataset which needs no key:
 * https://hudgis-hud.opendata.arcgis.com/datasets/HUD::multifamily-properties-assisted-insured/about
 * ArcGIS Feature Service (no auth): https://services.arcgis.com/VTyQ9soqVukalItT/arcgis/rest/services/Assisted_Housing_National/FeatureServer/0/query
 */
async function lookupHudStatus(address, complexName) {
  // Parse street number + name from address for fuzzy match
  const parts = address.split(",");
  const street = parts[0].trim().toUpperCase();
  const city = "KANSAS CITY";
  const state = "MO";

  // ArcGIS public feature service — HUD Multifamily Assisted/Insured Properties
  const base = "https://services.arcgis.com/VTyQ9soqVukalItT/arcgis/rest/services/Assisted_Housing_National/FeatureServer/0/query";
  const where = `UPPER(STD_ADDR) LIKE '%${encodeURIComponent(street.split(" ").slice(0,3).join(" "))}%' AND UPPER(CITY)='${city}' AND STATE='${state}'`;
  const url = `${base}?where=${where}&outFields=PROJECT_NAME,STD_ADDR,CITY,STATE,ZIP,PROGRAM_TYPE,UNITS,CONTRACT_EXP_DATE&f=json&resultRecordCount=5`;

  const res = await fetch(url);
  if (!res.ok) throw new Error(`HUD API ${res.status}`);
  const data = await res.json();

  if (!data.features || data.features.length === 0) return { status: "not_found", match: null };

  // Pick best match — prefer name match, fall back to address match
  const features = data.features.map((f) => f.attributes);
  const nameLower = complexName.toLowerCase();
  const nameMatch = features.find((f) =>
    f.PROJECT_NAME && f.PROJECT_NAME.toLowerCase().includes(nameLower.split(" ")[0])
  );
  const best = nameMatch || features[0];

  return {
    status: "confirmed",
    match: {
      projectName: best.PROJECT_NAME,
      address:     best.STD_ADDR,
      city:        best.CITY,
      state:       best.STATE,
      programType: best.PROGRAM_TYPE,
      units:       best.UNITS,
      contractExp: best.CONTRACT_EXP_DATE,
    },
  };
}

// ─── main component ────────────────────────────────────────────────────────────

export default function App() {
  const [isScanning,       setIsScanning]       = useState(false);
  const [scanProgress,     setScanProgress]     = useState(0);
  const [scanStage,        setScanStage]        = useState("");
  const [complaints,       setComplaints]       = useState([]);
  const [selectedSources,  setSelectedSources]  = useState(["kcdata","hud"]);
  const [filterSection8,   setFilterSection8]   = useState("all");
  const [filterSeverity,   setFilterSeverity]   = useState("all");
  const [filterKeyword,    setFilterKeyword]    = useState("");
  const [filterMinUnits,   setFilterMinUnits]   = useState("");
  const [selectedId,       setSelectedId]       = useState(null);
  const [aiAnalysis,       setAiAnalysis]       = useState("");
  const [isAnalyzing,      setIsAnalyzing]      = useState(false);
  const [scanComplete,     setScanComplete]     = useState(false);
  const [verifyingAll,     setVerifyingAll]     = useState(false);
  const [verifyProgress,   setVerifyProgress]   = useState({ done: 0, total: 0 });

  const selectedComplaint = complaints.find((c) => c.id === selectedId) || null;

  const totalContacts = complaints.reduce((s, c) => s + c.potentialContacts, 0);
  const confirmedSec8 = complaints.filter((c) => c.section8Status === "confirmed").length;
  const criticalCount = complaints.filter((c) => c.severity === "critical").length;
  const largeCount    = complaints.filter((c) => c.totalUnits >= 100).length;

  const updateComplaint = useCallback((id, patch) => {
    setComplaints((prev) => prev.map((c) => c.id === id ? { ...c, ...patch } : c));
  }, []);

  // Verify a single complaint against HUD API via backend
  const verifyOne = useCallback(async (complaint) => {
    updateComplaint(complaint.id, { section8Status: "checking" });
    try {
      if (BACKEND_URL.includes("YOUR-RAILWAY-URL")) {
        // No backend yet — fall through to direct ArcGIS call
        throw new Error("no backend");
      }
      const res = await fetch(`${BACKEND_URL}/api/verify-hud`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ address: complaint.address, complexName: complaint.complex }),
      });
      if (!res.ok) throw new Error(`verify-hud returned ${res.status}`);
      const data = await res.json();
      updateComplaint(complaint.id, { section8Status: data.status, hudMatch: data.match });
    } catch (err) {
      // Fallback: try ArcGIS directly from browser (may hit CORS)
      try {
        const result = await lookupHudStatus(complaint.address, complaint.complex);
        updateComplaint(complaint.id, { section8Status: result.status, hudMatch: result.match });
      } catch {
        updateComplaint(complaint.id, {
          section8Status: "unverified",
          hudMatch: { error: "HUD API unreachable — deploy backend or verify manually at huduser.gov" },
        });
      }
    }
  }, [updateComplaint]);

  // Verify all complaints sequentially
  const verifyAll = useCallback(async () => {
    setVerifyingAll(true);
    const ids = complaints.map((c) => c.id);
    setVerifyProgress({ done: 0, total: ids.length });
    for (let i = 0; i < complaints.length; i++) {
      await verifyOne(complaints[i]);
      setVerifyProgress({ done: i + 1, total: ids.length });
    }
    setVerifyingAll(false);
  }, [complaints, verifyOne]);

  const toggleSource = (id) =>
    setSelectedSources((prev) => prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]);

  const runScan = async () => {
    setIsScanning(true); setScanProgress(0); setScanComplete(false);
    setComplaints([]); setAiAnalysis(""); setSelectedId(null);

    // Check if backend is configured
    if (BACKEND_URL.includes("YOUR-RAILWAY-URL")) {
      setScanStage("⚠ Backend not configured yet — showing demo data. See README to deploy.");
      await new Promise((r) => setTimeout(r, 2000));
      setComplaints(INITIAL_COMPLAINTS.map((c) => ({ ...c, section8Status: "unverified", hudMatch: null })));
      setIsScanning(false);
      setScanComplete(true);
      return;
    }

    // Determine which sources the backend supports
    const backendSources = selectedSources.filter((s) => ["kcdata", "hud"].includes(s));
    const sourcesParam   = backendSources.join(",") || "reddit,hud";

    try {
      setScanStage("Connecting to backend server…");
      setScanProgress(5);

      // Hit the health endpoint first to confirm the server is up
      const health = await fetch(`${BACKEND_URL}/health`);
      if (!health.ok) throw new Error("Backend server not reachable");
      const healthData = await health.json();

      if (!healthData.env?.redditConfigured) {
        setScanStage("Querying KC Open Data property violations…");
      } else {
        setScanStage("Querying KC Open Data property violations…");
      }
      setScanProgress(15);

      setScanStage(`Fetching live data (${sourcesParam})…`);
      setScanProgress(30);

      const res  = await fetch(`${BACKEND_URL}/api/scan?sources=${sourcesParam}`);
      if (!res.ok) throw new Error(`API returned ${res.status}`);

      setScanProgress(70);
      setScanStage("Processing results…");

      const data = await res.json();

      setScanProgress(85);
      setScanStage("Filtering by complaint keywords…");
      await new Promise((r) => setTimeout(r, 400));

      setScanProgress(95);
      setScanStage("Ranking by severity…");
      await new Promise((r) => setTimeout(r, 300));

      // Surface any partial errors from the backend
      if (data.errors?.length) {
        console.warn("Backend partial errors:", data.errors);
      }

      setComplaints(data.results || []);
      setScanProgress(100);
      setScanStage(`Found ${data.count} complaints`);

    } catch (err) {
      console.error("Scan failed:", err);
      setScanStage(`⚠ Error: ${err.message} — falling back to demo data`);
      await new Promise((r) => setTimeout(r, 1500));
      setComplaints(INITIAL_COMPLAINTS.map((c) => ({ ...c, section8Status: "unverified", hudMatch: null })));
    }

    setIsScanning(false);
    setScanComplete(true);
  };

  const runAiAnalysis = async (c) => {
    setIsAnalyzing(true); setAiAnalysis("");
    const sec8Label =
      c.section8Status === "confirmed" ? `Yes — HUD confirmed (${c.hudMatch?.programType || "program type unknown"})` :
      c.section8Status === "not_found" ? "No — not found in HUD database" :
      "Unverified — manual HUD check needed";
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: `You are a legal intake assistant helping a plaintiff's attorney evaluate housing complaints for potential class action litigation under Missouri law.
Analyze for: (1) Habitability law violations, (2) Class action viability — note if large corporate management company and/or HUD-subsidized status strengthens the case, (3) Strongest legal theories, (4) Suggested tenant outreach approach, (5) Key documentation to request.
Use clear labeled section headers. Be concise and legally specific. Under 500 words.`,
          messages: [{
            role: "user",
            content: `Complex: ${c.complex}
Address: ${c.address}
Management: ${c.managementCompany}
Total Units: ${c.totalUnits}
Year Built: ${c.yearBuilt}
HUD/Section 8 Status: ${sec8Label}
Issues: ${c.tags.join(", ")}
Complaint: ${c.text}
Potential Contacts: ${c.potentialContacts}
Severity: ${c.severity}
Source: ${c.platform}
Date: ${c.date}`,
          }],
        }),
      });
      const data = await res.json();
      setAiAnalysis(data.content.map((b) => b.text || "").join("\n"));
    } catch {
      setAiAnalysis("Analysis unavailable — check API connection.");
    }
    setIsAnalyzing(false);
  };

  const filtered = complaints.filter((c) => {
    if (!selectedSources.includes(c.source)) return false;
    if (filterSection8 === "confirmed" && c.section8Status !== "confirmed") return false;
    if (filterSection8 === "unverified" && c.section8Status !== "unverified") return false;
    if (filterSeverity !== "all" && c.severity !== filterSeverity) return false;
    if (filterMinUnits && c.totalUnits < parseInt(filterMinUnits)) return false;
    if (filterKeyword) {
      const kw = filterKeyword.toLowerCase();
      return c.text.toLowerCase().includes(kw)
        || c.complex.toLowerCase().includes(kw)
        || c.managementCompany.toLowerCase().includes(kw)
        || c.tags.some((t) => t.toLowerCase().includes(kw));
    }
    return true;
  });

  // ── style helpers ──────────────────────────────────────────────────────────
  const pill = (bg, color, extra = {}) => ({
    background: bg, color,
    fontSize: 9, fontWeight: 700, padding: "2px 7px",
    borderRadius: 2, letterSpacing: "0.1em", whiteSpace: "nowrap",
    ...extra,
  });

  const Sec8Badge = ({ status, inline = false }) => {
    const cfg = sec8Config[status] || sec8Config.unverified;
    return (
      <span style={{
        background: cfg.bg, color: cfg.color,
        border: `1px solid ${cfg.border}`,
        fontSize: inline ? 8 : 9, fontWeight: 700,
        padding: inline ? "1px 5px" : "2px 7px",
        borderRadius: 2, letterSpacing: "0.08em", whiteSpace: "nowrap",
        display: "inline-flex", alignItems: "center", gap: 3,
      }}>
        <span style={{ fontSize: status === "checking" ? 10 : 9 }}>{cfg.icon}</span>
        {cfg.label}
      </span>
    );
  };

  // ── render ─────────────────────────────────────────────────────────────────
  return (
    <div style={{ fontFamily: "'IBM Plex Mono','Courier New',monospace", background: "#0a0a0f", minHeight: "100vh", color: "#e0e0e0" }}>

      {/* HEADER */}
      <div style={{
        background: "linear-gradient(135deg,#0d1117 0%,#1a0a2e 100%)",
        borderBottom: "2px solid #C62828",
        padding: "15px 26px", display: "flex", alignItems: "center", gap: 13,
      }}>
        <div style={{
          width: 38, height: 38, background: "#C62828", fontSize: 16, fontWeight: 900, color: "#fff",
          display: "flex", alignItems: "center", justifyContent: "center",
          clipPath: "polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%)",
        }}>⚖</div>
        <div>
          <div style={{ fontSize: 17, fontWeight: 700, color: "#fff", letterSpacing: "0.08em" }}>KC HOUSING INTEL</div>
          <div style={{ fontSize: 9, color: "#C62828", letterSpacing: "0.22em" }}>CLASS ACTION LEAD DISCOVERY — KANSAS CITY METRO</div>
        </div>
        {scanComplete && (
          <div style={{ marginLeft: "auto", display: "flex", gap: 22, alignItems: "center" }}>
            {[
              { label: "COMPLAINTS",    val: complaints.length, color: "#FF6D00" },
              { label: "HUD CONFIRMED", val: confirmedSec8,     color: "#69F0AE" },
              { label: "CRITICAL",      val: criticalCount,     color: "#FF1744" },
              { label: "LARGE (100+)",  val: largeCount,        color: "#b090d0" },
              { label: "CONTACTS",      val: totalContacts,     color: "#4285F4" },
            ].map((s) => (
              <div key={s.label} style={{ textAlign: "center" }}>
                <div style={{ fontSize: 20, fontWeight: 900, color: s.color }}>{s.val}</div>
                <div style={{ fontSize: 8, color: "#555", letterSpacing: "0.1em" }}>{s.label}</div>
              </div>
            ))}
            {/* Verify All button */}
            <button
              onClick={verifyAll}
              disabled={verifyingAll || isScanning}
              style={{
                marginLeft: 10,
                background: verifyingAll ? "#0a1a2a" : "linear-gradient(135deg,#0a2a1a,#0d4a2a)",
                border: `1px solid ${verifyingAll ? "#1a4a6a" : "#2E7D32"}`,
                color: verifyingAll ? "#4499cc" : "#69F0AE",
                fontSize: 10, fontWeight: 700, padding: "7px 14px",
                borderRadius: 3, cursor: verifyingAll ? "not-allowed" : "pointer",
                letterSpacing: "0.1em", whiteSpace: "nowrap",
              }}
            >
              {verifyingAll
                ? `HUD CHECKING… ${verifyProgress.done}/${verifyProgress.total}`
                : "⟳ VERIFY ALL HUD"}
            </button>
          </div>
        )}
      </div>

      <div style={{ display: "flex", height: "calc(100vh - 74px)" }}>

        {/* SIDEBAR */}
        <div style={{ width: 260, background: "#0d1117", borderRight: "1px solid #1e2530", padding: "18px 12px", overflowY: "auto", flexShrink: 0 }}>

          <div style={{ fontSize: 9, color: "#C62828", letterSpacing: "0.22em", marginBottom: 8 }}>DATA SOURCES</div>
          {SEARCH_CONFIGS.map((src) => (
            <div key={src.id} onClick={() => toggleSource(src.id)} style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "7px 8px", marginBottom: 4, borderRadius: 3, cursor: "pointer",
              background: selectedSources.includes(src.id) ? "#1a1f2e" : "transparent",
              border: `1px solid ${selectedSources.includes(src.id) ? src.color : "#1e2530"}`,
            }}>
              <div style={{
                width: 22, height: 22, borderRadius: 2, flexShrink: 0,
                background: selectedSources.includes(src.id) ? src.color : "#1e2530",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 10, fontWeight: 900, color: selectedSources.includes(src.id) ? "#fff" : "#444",
              }}>{src.icon}</div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: selectedSources.includes(src.id) ? "#fff" : "#555" }}>{src.label}</div>
                <div style={{ fontSize: 9, color: "#3a3a4a", lineHeight: 1.3 }}>{src.description}</div>
              </div>
            </div>
          ))}

          <div style={{ marginTop: 18, borderTop: "1px solid #1e2530", paddingTop: 14 }}>
            <div style={{ fontSize: 9, color: "#C62828", letterSpacing: "0.22em", marginBottom: 9 }}>FILTERS</div>

            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 9, color: "#555", marginBottom: 4, letterSpacing: "0.1em" }}>HUD / SECTION 8</div>
              <select value={filterSection8} onChange={(e) => setFilterSection8(e.target.value)} style={{
                width: "100%", background: "#1a1f2e", border: "1px solid #2a3040",
                color: "#e0e0e0", padding: "5px 7px", fontSize: 10, borderRadius: 3,
              }}>
                <option value="all">All Properties</option>
                <option value="confirmed">✓ HUD Confirmed Only</option>
                <option value="unverified">? Unverified Only</option>
              </select>
            </div>

            {[
              { label: "SEVERITY", val: filterSeverity, set: setFilterSeverity,
                opts: [["all","All Severities"],["critical","Critical"],["high","High"],["medium","Medium"]] },
              { label: "MIN UNIT COUNT", val: filterMinUnits, set: setFilterMinUnits,
                opts: [["","Any size"],["50","50+ units"],["100","100+ (Mid-size)"],["200","200+ (Large)"],["300","300+ (Very large)"]] },
            ].map(({ label, val, set, opts }) => (
              <div key={label} style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 9, color: "#555", marginBottom: 4, letterSpacing: "0.1em" }}>{label}</div>
                <select value={val} onChange={(e) => set(e.target.value)} style={{
                  width: "100%", background: "#1a1f2e", border: "1px solid #2a3040",
                  color: "#e0e0e0", padding: "5px 7px", fontSize: 10, borderRadius: 3,
                }}>
                  {opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
              </div>
            ))}

            <div style={{ fontSize: 9, color: "#555", marginBottom: 4, letterSpacing: "0.1em" }}>KEYWORD / MGMT CO.</div>
            <input
              placeholder="mold, Yarco, rats…"
              value={filterKeyword}
              onChange={(e) => setFilterKeyword(e.target.value)}
              style={{
                width: "100%", background: "#1a1f2e", border: "1px solid #2a3040",
                color: "#e0e0e0", padding: "5px 7px", fontSize: 10, borderRadius: 3, boxSizing: "border-box",
              }}
            />
          </div>

          {/* HUD legend */}
          <div style={{ marginTop: 18, borderTop: "1px solid #1e2530", paddingTop: 14 }}>
            <div style={{ fontSize: 9, color: "#C62828", letterSpacing: "0.22em", marginBottom: 9 }}>HUD STATUS KEY</div>
            {Object.entries(sec8Config).filter(([k]) => k !== "checking").map(([key, cfg]) => (
              <div key={key} style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 6 }}>
                <span style={{
                  background: cfg.bg, color: cfg.color, border: `1px solid ${cfg.border}`,
                  fontSize: 8, padding: "1px 5px", borderRadius: 2, whiteSpace: "nowrap",
                }}>{cfg.icon} {cfg.label}</span>
                <span style={{ fontSize: 9, color: "#444" }}>
                  {key === "confirmed"  && "Found in HUD DB"}
                  {key === "not_found"  && "Not subsidized"}
                  {key === "unverified" && "Not yet checked"}
                </span>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 16, borderTop: "1px solid #1e2530", paddingTop: 13 }}>
            <div style={{ fontSize: 9, color: "#C62828", letterSpacing: "0.22em", marginBottom: 8 }}>TARGET KEYWORDS</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 3 }}>
              {KEYWORDS.slice(0, 12).map((kw) => (
                <span key={kw} style={{ background: "#1a0a2e", border: "1px solid #3a1a4e", color: "#b090d0", fontSize: 8, padding: "2px 5px", borderRadius: 2 }}>{kw}</span>
              ))}
            </div>
          </div>

          <button onClick={runScan} disabled={isScanning} style={{
            marginTop: 20, width: "100%",
            background: isScanning ? "#1a1f2e" : "linear-gradient(135deg,#C62828,#8B0000)",
            border: "none", color: isScanning ? "#555" : "#fff",
            padding: "11px 0", fontSize: 11, fontWeight: 700,
            letterSpacing: "0.14em", cursor: isScanning ? "not-allowed" : "pointer", borderRadius: 3,
          }}>
            {isScanning ? "SCANNING…" : "▶  RUN SCAN"}
          </button>
        </div>

        {/* MAIN LIST */}
        <div style={{ flex: 1, overflowY: "auto" }}>

          {isScanning && (
            <div style={{ background: "#0d1117", borderBottom: "1px solid #1e2530", padding: "15px 22px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 7 }}>
                <span style={{ fontSize: 11, color: "#69F0AE" }}>{scanStage}</span>
                <span style={{ fontSize: 11, color: "#69F0AE", fontWeight: 700 }}>{scanProgress}%</span>
              </div>
              <div style={{ background: "#1e2530", borderRadius: 2, height: 4 }}>
                <div style={{ width: `${scanProgress}%`, height: "100%", background: "linear-gradient(90deg,#C62828,#FF6D00)", borderRadius: 2, transition: "width 0.4s ease" }} />
              </div>
            </div>
          )}

          {!isScanning && complaints.length === 0 && (
            <div style={{ height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12, opacity: 0.35 }}>
              <div style={{ fontSize: 40 }}>⚖</div>
              <div style={{ fontSize: 12, color: "#666", textAlign: "center" }}>
                Select sources and click RUN SCAN<br />to discover KC housing complaints.
              </div>
            </div>
          )}

          {/* notice bar when results loaded but unverified */}
          {complaints.length > 0 && complaints.some((c) => c.section8Status === "unverified") && !verifyingAll && (
            <div style={{
              background: "#1a1200", borderBottom: "1px solid #5a4000",
              padding: "9px 22px", display: "flex", alignItems: "center", gap: 10,
            }}>
              <span style={{ fontSize: 12 }}>⚠</span>
              <span style={{ fontSize: 11, color: "#FFD600" }}>
                HUD/Section 8 status is <strong>unverified</strong> for all properties. Click{" "}
                <strong>⟳ VERIFY ALL HUD</strong> in the header or verify individually in the detail panel.
              </span>
            </div>
          )}

          {filtered.length > 0 && (
            <div style={{ padding: "14px 20px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 11 }}>
                <div style={{ fontSize: 10, color: "#555", letterSpacing: "0.14em" }}>
                  {filtered.length} COMPLAINTS &nbsp;·&nbsp; {filtered.reduce((s, c) => s + c.potentialContacts, 0)} POTENTIAL CONTACTS
                </div>
                <div style={{ fontSize: 9, color: "#3a3a4a" }}>Click row for detail + AI analysis</div>
              </div>

              {filtered.map((c) => {
                const sz = sizeLabel(c.totalUnits);
                const sel = selectedId === c.id;
                return (
                  <div key={c.id} onClick={() => { setSelectedId(c.id); setAiAnalysis(""); }} style={{
                    background: sel ? "#1a1f2e" : "#0d1117",
                    border: `1px solid ${sel ? "#C62828" : "#1e2530"}`,
                    borderRadius: 5, padding: "12px 15px", marginBottom: 8,
                    cursor: "pointer", transition: "all 0.15s",
                  }}>
                    {/* row 1: name + badges */}
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap", flex: 1, marginRight: 8 }}>
                        <span style={{ fontSize: 13, fontWeight: 700, color: "#fff" }}>{c.complex}</span>
                        <span style={pill("#1a0a2e", sz.color, { border: `1px solid ${sz.color}44` })}>
                          {sz.label} · {c.totalUnits ? `${c.totalUnits} units` : "units TBD"}
                        </span>
                        <span style={pill(severityConfig[c.severity].bg, severityConfig[c.severity].text)}>
                          {severityConfig[c.severity].label}
                        </span>
                      </div>
                      <span style={{ ...pill("#1a0a2e","#b090d0"), border: "1px solid #3a1a4e", flexShrink: 0 }}>
                        {c.potentialContacts} contacts
                      </span>
                    </div>

                    {/* row 2: HUD status + address + mgmt */}
                    <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 4, flexWrap: "wrap" }}>
                      {/* inline HUD badge */}
                      {(() => {
                        const cfg = sec8Config[c.section8Status] || sec8Config.unverified;
                        return (
                          <span style={{
                            background: cfg.bg, color: cfg.color, border: `1px solid ${cfg.border}`,
                            fontSize: 8, fontWeight: 700, padding: "1px 5px", borderRadius: 2,
                            display: "inline-flex", alignItems: "center", gap: 3, whiteSpace: "nowrap",
                          }}>
                            {cfg.icon} {cfg.label}
                          </span>
                        );
                      })()}
                      <span style={{ fontSize: 10, color: "#555" }}>{c.address}</span>
                    </div>

                    {/* row 3: management */}
                    <div style={{ fontSize: 10, color: "#5a7a9a", marginBottom: 5 }}>Mgmt: {c.managementCompany}</div>

                    {/* row 4: source dot + platform + link */}
                    <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 6, flexWrap: "wrap" }}>
                      <span style={{ width: 7, height: 7, borderRadius: "50%", background: sourceColors[c.source] || "#555", display: "inline-block", flexShrink: 0 }} />
                      <span style={{ fontSize: 9, color: "#444" }}>{c.platform} · {c.date}</span>
                      <a href={c.url} target="_blank" rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        style={{ fontSize: 9, color: "#4285F4", textDecoration: "none", border: "1px solid #4285F433", padding: "1px 5px", borderRadius: 2 }}>
                        View source ↗
                      </a>
                    </div>

                    {/* tags */}
                    <div style={{ display: "flex", gap: 4, marginBottom: 6, flexWrap: "wrap" }}>
                      {c.tags.map((t) => <span key={t} style={{ background: "#1a1020", border: "1px solid #3a2040", color: "#FF6D00", fontSize: 8, padding: "2px 5px", borderRadius: 2 }}>{t}</span>)}
                    </div>

                    {/* excerpt */}
                    <div style={{ fontSize: 10, color: "#777", lineHeight: 1.6, fontStyle: "italic" }}>
                      "{c.text.length > 185 ? c.text.slice(0, 185) + "…" : c.text}"
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* DETAIL PANEL */}
        {selectedComplaint && (
          <div style={{ width: 355, background: "#0d1117", borderLeft: "1px solid #1e2530", padding: "18px 15px", overflowY: "auto", flexShrink: 0 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div style={{ fontSize: 9, color: "#C62828", letterSpacing: "0.22em" }}>COMPLAINT DETAIL</div>
              <button onClick={() => setSelectedId(null)} style={{ background: "none", border: "none", color: "#555", fontSize: 16, cursor: "pointer" }}>✕</button>
            </div>

            <div style={{ fontSize: 14, fontWeight: 700, color: "#fff", marginBottom: 4 }}>{selectedComplaint.complex}</div>
            <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginBottom: 12 }}>
              <span style={pill(severityConfig[selectedComplaint.severity].bg, severityConfig[selectedComplaint.severity].text)}>
                {severityConfig[selectedComplaint.severity].label}
              </span>
              {(() => { const s = sizeLabel(selectedComplaint.totalUnits); return <span style={pill("#1a0a2e", s.color, { border: `1px solid ${s.color}44` })}>{s.label}</span>; })()}
              <span style={{ ...pill("#1a0a2e","#b090d0"), border:"1px solid #3a1a4e" }}>{selectedComplaint.potentialContacts} contacts</span>
            </div>

            {/* HUD Verification block */}
            <div style={{
              background: "#0a1020", border: `1px solid ${sec8Config[selectedComplaint.section8Status]?.border || "#1e2530"}`,
              borderRadius: 4, padding: "13px", marginBottom: 11,
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                <div style={{ fontSize: 9, color: "#C62828", letterSpacing: "0.18em" }}>HUD / SECTION 8 STATUS</div>
                <button
                  onClick={() => verifyOne(selectedComplaint)}
                  disabled={selectedComplaint.section8Status === "checking"}
                  style={{
                    background: "#0a2a1a", border: "1px solid #2E7D32",
                    color: selectedComplaint.section8Status === "checking" ? "#4499cc" : "#69F0AE",
                    fontSize: 9, padding: "3px 9px", borderRadius: 2, cursor: "pointer", fontWeight: 700,
                    letterSpacing: "0.08em",
                  }}
                >
                  {selectedComplaint.section8Status === "checking" ? "CHECKING…" : "⟳ VERIFY NOW"}
                </button>
              </div>

              {/* Status badge */}
              <div style={{ marginBottom: 10 }}>
                {(() => {
                  const cfg = sec8Config[selectedComplaint.section8Status] || sec8Config.unverified;
                  return (
                    <span style={{
                      background: cfg.bg, color: cfg.color, border: `1px solid ${cfg.border}`,
                      fontSize: 11, fontWeight: 700, padding: "5px 10px",
                      borderRadius: 3, display: "inline-flex", alignItems: "center", gap: 5,
                    }}>
                      <span style={{ fontSize: 14 }}>{cfg.icon}</span> {cfg.label}
                    </span>
                  );
                })()}
              </div>

              {/* HUD match data */}
              {selectedComplaint.section8Status === "confirmed" && selectedComplaint.hudMatch && (
                <div style={{ fontSize: 10, lineHeight: 1.8 }}>
                  {[
                    ["HUD Project Name", selectedComplaint.hudMatch.projectName],
                    ["Program Type",     selectedComplaint.hudMatch.programType],
                    ["HUD Units",        selectedComplaint.hudMatch.units],
                    ["Contract Exp.",    selectedComplaint.hudMatch.contractExp],
                  ].map(([lbl, val]) => val ? (
                    <div key={lbl} style={{ display: "flex", justifyContent: "space-between" }}>
                      <span style={{ color: "#555" }}>{lbl}</span>
                      <span style={{ color: "#ccc" }}>{val}</span>
                    </div>
                  ) : null)}
                  <a href={`https://hudgis-hud.opendata.arcgis.com/`} target="_blank" rel="noopener noreferrer"
                    style={{ fontSize: 9, color: "#4285F4", textDecoration: "none" }}>
                    View on HUD Open Data ↗
                  </a>
                </div>
              )}

              {selectedComplaint.section8Status === "not_found" && (
                <div style={{ fontSize: 10, color: "#666", lineHeight: 1.7 }}>
                  Not found in HUD Multifamily Assisted/Insured database.<br />
                  May accept tenant-based (portable) vouchers — check{" "}
                  <a href="https://affordablehousingonline.com/housing-search/Missouri/Kansas-City" target="_blank" rel="noopener noreferrer"
                    style={{ color: "#4285F4" }}>AffordableHousingOnline ↗</a>
                </div>
              )}

              {selectedComplaint.section8Status === "unverified" && (
                <div style={{ fontSize: 10, color: "#999", lineHeight: 1.7 }}>
                  Not yet checked. Click <strong style={{ color: "#FFD600" }}>⟳ VERIFY NOW</strong> to query the HUD Multifamily Assisted Housing database in real time.
                  <div style={{ marginTop: 6, color: "#555" }}>
                    Data source: HUD ArcGIS Open Data (no API key required)
                  </div>
                </div>
              )}

              {selectedComplaint.hudMatch?.error && (
                <div style={{ fontSize: 10, color: "#FF6D00", marginTop: 6 }}>
                  ⚠ {selectedComplaint.hudMatch.error}
                </div>
              )}
            </div>

            {/* Property info */}
            <div style={{ background: "#0a1020", border: "1px solid #1e2530", borderRadius: 4, padding: "12px", marginBottom: 10 }}>
              <div style={{ fontSize: 9, color: "#C62828", letterSpacing: "0.18em", marginBottom: 8 }}>PROPERTY INFO</div>
              {[
                ["ADDRESS",     selectedComplaint.address],
                ["TOTAL UNITS", selectedComplaint.totalUnits ? `${selectedComplaint.totalUnits} units` : "Unknown"],
                ["YEAR BUILT",  selectedComplaint.yearBuilt || "Unknown"],
              ].map(([lbl, val]) => (
                <div key={lbl} style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ fontSize: 9, color: "#555", letterSpacing: "0.08em" }}>{lbl}</span>
                  <span style={{ fontSize: 11, color: "#ccc", textAlign: "right" }}>{val}</span>
                </div>
              ))}
            </div>

            {/* Management */}
            <div style={{ background: "#0a1020", border: "1px solid #1e2530", borderRadius: 4, padding: "12px", marginBottom: 10 }}>
              <div style={{ fontSize: 9, color: "#C62828", letterSpacing: "0.18em", marginBottom: 8 }}>MANAGEMENT COMPANY</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#7a9cc0", marginBottom: 5 }}>{selectedComplaint.managementCompany}</div>
              <a href={selectedComplaint.managementWebsite} target="_blank" rel="noopener noreferrer"
                style={{ fontSize: 10, color: "#4285F4", textDecoration: "none" }}>
                {selectedComplaint.managementWebsite} ↗
              </a>
            </div>

            {/* Issues */}
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 9, color: "#555", letterSpacing: "0.1em", marginBottom: 5 }}>COMPLAINT ISSUES</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                {selectedComplaint.tags.map((t) => <span key={t} style={{ background: "#1a1020", border: "1px solid #3a2040", color: "#FF6D00", fontSize: 9, padding: "3px 7px", borderRadius: 2 }}>{t}</span>)}
              </div>
            </div>

            {/* Full text */}
            <div style={{ background: "#0a1020", border: "1px solid #1e2530", borderRadius: 4, padding: "12px", marginBottom: 10 }}>
              <div style={{ fontSize: 9, color: "#555", letterSpacing: "0.1em", marginBottom: 6 }}>FULL COMPLAINT</div>
              <div style={{ fontSize: 11, color: "#bbb", lineHeight: 1.8, fontStyle: "italic" }}>"{selectedComplaint.text}"</div>
            </div>

            {/* Source + link */}
            <div style={{ background: "#0a1020", border: "1px solid #1e2530", borderRadius: 4, padding: "12px", marginBottom: 14 }}>
              <div style={{ fontSize: 9, color: "#555", letterSpacing: "0.1em", marginBottom: 6 }}>SOURCE & DIRECT LINK</div>
              <div style={{ fontSize: 11, color: "#69F0AE", marginBottom: 3 }}>{selectedComplaint.contact}</div>
              <div style={{ fontSize: 9, color: "#444", marginBottom: 8, display: "flex", alignItems: "center", gap: 4 }}>
                <span style={{ width: 6, height: 6, borderRadius: "50%", background: sourceColors[selectedComplaint.source] || "#555", display: "inline-block" }} />
                {selectedComplaint.platform} · {selectedComplaint.date}
              </div>
              <a href={selectedComplaint.url} target="_blank" rel="noopener noreferrer"
                style={{ display: "block", background: "#0d2040", border: "1px solid #4285F455", borderRadius: 3, color: "#4285F4", fontSize: 10, padding: "7px 9px", textDecoration: "none", wordBreak: "break-all", lineHeight: 1.6 }}>
                🔗 {selectedComplaint.url}
              </a>
            </div>

            {/* AI analysis */}
            <button onClick={() => runAiAnalysis(selectedComplaint)} disabled={isAnalyzing} style={{
              width: "100%",
              background: isAnalyzing ? "#1a1f2e" : "linear-gradient(135deg,#1a0a2e,#3a1a4e)",
              border: "1px solid #C62828", color: isAnalyzing ? "#555" : "#fff",
              padding: "10px 0", fontSize: 10, fontWeight: 700,
              letterSpacing: "0.12em", cursor: isAnalyzing ? "not-allowed" : "pointer", borderRadius: 3,
            }}>
              {isAnalyzing ? "ANALYZING…" : "⚖  AI LEGAL INTAKE ANALYSIS"}
            </button>

            {aiAnalysis && (
              <div style={{ marginTop: 13, borderTop: "1px solid #1e2530", paddingTop: 13 }}>
                <div style={{ fontSize: 9, color: "#C62828", letterSpacing: "0.2em", marginBottom: 8 }}>AI LEGAL ANALYSIS</div>
                <div style={{ fontSize: 11, color: "#ccc", lineHeight: 1.9, whiteSpace: "pre-wrap" }}>{aiAnalysis}</div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
