# KC Housing Intel — Backend v2 Deployment Guide

## Good news: NO API KEYS REQUIRED
Both data sources are fully public government datasets:
- **KC Open Data** (data.kcmo.org) — property violations, updated daily
- **HUD Multifamily ArcGIS** — subsidized housing database

---

## Step 1 — Push to GitHub

```bash
# In this folder:
git init
git add .
git commit -m "KC Housing Intel backend v2"
```

Create a new repo at https://github.com/new, then:

```bash
git remote add origin https://github.com/YOUR_USERNAME/kc-housing-backend.git
git push -u origin main
```

---

## Step 2 — Deploy to Railway

1. Log in at https://railway.app
2. Click **"New Project"** → **"Deploy from GitHub repo"**
3. Connect GitHub if prompted, then select your repo
4. Railway auto-detects Node.js — no build config needed
5. Click **"Deploy"**

---

## Step 3 — Set environment variables (optional)

In Railway → your service → **Variables** tab:

| Variable         | Value                          | Required? |
|------------------|--------------------------------|-----------|
| `ALLOWED_ORIGIN` | `*` or your frontend URL       | Optional  |

That's it — no other variables needed.

---

## Step 4 — Get your URL

Railway → your service → **Settings** → **Domains** → **Generate Domain**

You'll get something like:
`https://kc-housing-intel-backend-production.up.railway.app`

---

## Step 5 — Wire up the frontend

In the KC Housing Intel React artifact, find:

```js
const BACKEND_URL = "https://YOUR-RAILWAY-URL.up.railway.app";
```

Replace with your actual Railway URL.

---

## Verify it's working

Open in browser:
```
https://your-railway-url.up.railway.app/health
```

Expected response:
```json
{
  "status": "ok",
  "sources": {
    "kcViolations": "KC Open Data EnerGov — no key required",
    "hud": "HUD ArcGIS Multifamily — no key required"
  }
}
```

Test live data (may take ~10 sec first run):
```
https://your-railway-url.up.railway.app/api/scan?sources=kcdata
```

---

## API Reference

| Method | Endpoint               | Description                                    |
|--------|------------------------|------------------------------------------------|
| GET    | `/health`              | Server status + cache state                    |
| GET    | `/api/scan`            | All complaints (KC violations + HUD)           |
| GET    | `/api/scan?sources=kcdata` | KC property violations only               |
| GET    | `/api/scan?sources=hud`    | HUD properties only                       |
| GET    | `/api/scan?fresh=true` | Force bypass 15-min cache                      |
| GET    | `/api/violations`      | Raw KC violation records                       |
| GET    | `/api/hud-properties`  | Raw HUD KC property list                       |
| POST   | `/api/verify-hud`      | Verify `{address, complexName}` against HUD DB |

---

## Data sources

### KC Open Data — Property Violations (EnerGov)
- URL: https://data.kcmo.org/Neighborhoods/Property-Violations-from-EnerGov/vq3e-m9ge
- Updated: Daily
- License: Public Domain U.S. Government
- Covers: All code enforcement violations filed with KC Neighborhood Preservation Division

### HUD Multifamily Assisted Housing
- URL: https://hudgis-hud.opendata.arcgis.com/
- Updated: Periodic
- License: Public
- Covers: All HUD-assisted/insured multifamily properties nationally

---

## Cost
- **Railway free tier**: 500 hours/month — sufficient for this use case
- **Both data sources**: Free, no usage limits for reasonable queries
