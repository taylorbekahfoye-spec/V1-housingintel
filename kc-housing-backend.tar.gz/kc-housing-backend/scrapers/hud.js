// scrapers/hud.js
// Queries HUD's public ArcGIS Multifamily Assisted Housing feature service
// No API key required — fully public dataset
// https://hudgis-hud.opendata.arcgis.com/datasets/HUD::multifamily-properties-assisted-insured

const axios = require("axios");

const HUD_ARCGIS_URL =
  "https://services.arcgis.com/VTyQ9soqVukalItT/arcgis/rest/services/Assisted_Housing_National/FeatureServer/0/query";

const KC_CITIES = [
  "KANSAS CITY", "KANSAS CITY MO", "KANSAS CITY KS",
  "OVERLAND PARK", "INDEPENDENCE", "LEES SUMMIT", "LEE'S SUMMIT",
  "OLATHE", "SHAWNEE",
];

async function fetchKCHudProperties() {
  const where = `(STATE='MO' OR STATE='KS') AND (${KC_CITIES.map((c) => `UPPER(CITY)='${c}'`).join(" OR ")})`;

  const params = {
    where,
    outFields: [
      "PROJECT_NAME", "STD_ADDR", "CITY", "STATE", "ZIP",
      "PROGRAM_TYPE", "UNITS", "CONTRACT_EXP_DATE",
      "OWNER_COMPANY", "MGMT_COMPANY", "MGMT_AGENT",
    ].join(","),
    f: "json",
    resultRecordCount: 1000,
    orderByFields: "PROJECT_NAME ASC",
  };

  const response = await axios.get(HUD_ARCGIS_URL, { params, timeout: 15000 });

  if (!response.data?.features) throw new Error("Unexpected HUD API response");

  return response.data.features.map((f) => ({
    projectName:  f.attributes.PROJECT_NAME,
    address:      f.attributes.STD_ADDR,
    city:         f.attributes.CITY,
    state:        f.attributes.STATE,
    zip:          f.attributes.ZIP,
    programType:  f.attributes.PROGRAM_TYPE,
    units:        f.attributes.UNITS,
    contractExp:  f.attributes.CONTRACT_EXP_DATE
      ? new Date(f.attributes.CONTRACT_EXP_DATE).toISOString().split("T")[0]
      : null,
    ownerCompany: f.attributes.OWNER_COMPANY,
    mgmtCompany:  f.attributes.MGMT_COMPANY || f.attributes.MGMT_AGENT,
  }));
}

async function verifyHudStatus(address, complexName, cachedProperties = null) {
  const properties = cachedProperties || await fetchKCHudProperties();
  if (!properties.length) return { status: "not_found", match: null };

  const addrNorm = normalizeStr(address);
  const nameNorm = normalizeStr(complexName);

  const scored = properties.map((p) => {
    let score = 0;
    const pAddr = normalizeStr(`${p.address} ${p.city}`);
    const pName = normalizeStr(p.projectName || "");

    const addrTokens = addrNorm.split(" ").slice(0, 3);
    score += addrTokens.filter((t) => t.length > 2 && pAddr.includes(t)).length * 2;

    const nameTokens = nameNorm.split(" ").filter((t) => t.length > 3);
    score += nameTokens.filter((t) => pName.includes(t)).length * 3;

    return { ...p, score };
  });

  const best = scored.sort((a, b) => b.score - a.score)[0];
  if (best.score < 2) return { status: "not_found", match: null };

  return {
    status: "confirmed",
    match: {
      projectName:  best.projectName,
      address:      `${best.address}, ${best.city}, ${best.state} ${best.zip || ""}`.trim(),
      programType:  best.programType,
      units:        best.units,
      contractExp:  best.contractExp,
      ownerCompany: best.ownerCompany,
      mgmtCompany:  best.mgmtCompany,
    },
  };
}

async function hudPropertiesAsLeads(cachedProperties = null) {
  const properties = cachedProperties || await fetchKCHudProperties();

  return properties.map((p, i) => ({
    id: `hud_${i}`,
    source: "hud",
    platform: "HUD Multifamily Database",
    date: new Date().toISOString().split("T")[0],
    complex: p.projectName || "Unknown",
    address: `${p.address}, ${p.city}, ${p.state}`,
    managementCompany: p.mgmtCompany || p.ownerCompany || "Unknown",
    managementWebsite: null,
    totalUnits: p.units,
    yearBuilt: null,
    section8Status: "confirmed",
    hudMatch: {
      projectName:  p.projectName,
      programType:  p.programType,
      units:        p.units,
      contractExp:  p.contractExp,
      ownerCompany: p.ownerCompany,
      mgmtCompany:  p.mgmtCompany,
    },
    tags: [],
    severity: "low",
    text: `HUD-assisted property. Program: ${p.programType || "Unknown"}. ${p.units ? `${p.units} units.` : ""} ${p.contractExp ? `Contract expires: ${p.contractExp}.` : ""}`,
    contact: "HUD Multifamily Database",
    url: "https://hudgis-hud.opendata.arcgis.com/",
    potentialContacts: p.units ? Math.floor(p.units * 0.1) : 0,
  }));
}

function normalizeStr(str) {
  return (str || "").toUpperCase().replace(/[^A-Z0-9\s]/g, "").replace(/\s+/g, " ").trim();
}

module.exports = { fetchKCHudProperties, verifyHudStatus, hudPropertiesAsLeads };
