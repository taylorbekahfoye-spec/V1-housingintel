// scrapers/kcViolations.js
// Queries Kansas City's public Open Data portal (Socrata API) for property violations
// Dataset: Property Violations from EnerGov — updated daily, no API key required
// https://data.kcmo.org/Neighborhoods/Property-Violations-from-EnerGov/vq3e-m9ge

const axios = require("axios");

const SOCRATA_BASE = "https://data.kcmo.org/resource/vq3e-m9ge.json";

// Housing-specific violation keywords that indicate habitability issues
const HOUSING_KEYWORDS = [
  "MOLD", "RODENT", "RAT", "MICE", "MOUSE", "PEST", "INFESTATION",
  "ROACH", "COCKROACH", "BED BUG", "BEDBUG", "INSECT",
  "HEAT", "HOT WATER", "PLUMBING", "SEWAGE", "SEWER",
  "STRUCTURAL", "UNSAFE", "UNFIT", "UNINHABITABLE", "HABITABILITY",
  "FLOODING", "WATER INTRUSION", "LEAK",
  "ELECTRICAL", "FIRE HAZARD", "SMOKE DETECTOR",
  "TRASH", "GARBAGE", "DEBRIS",  // often precede bigger issues
];

// Map KC ordinance chapters to issue tags
const CHAPTER_TAGS = {
  "48": ["property maintenance", "code violation"],
  "56": ["nuisance", "code violation"],
  "26": ["building code", "structural"],
  "18": ["fire code", "fire hazard"],
};

const SEVERITY_WEIGHTS = {
  "MOLD": 3, "UNINHABITABLE": 3, "UNFIT": 3, "SEWAGE": 3, "SEWER": 3,
  "UNSAFE": 3, "STRUCTURAL": 3, "FIRE HAZARD": 3,
  "RODENT": 2, "RAT": 2, "INFESTATION": 2, "BED BUG": 2, "BEDBUG": 2,
  "HEAT": 2, "HOT WATER": 2, "FLOODING": 2, "ELECTRICAL": 2,
  "PEST": 1, "ROACH": 1, "INSECT": 1, "PLUMBING": 1,
  "LEAK": 1, "WATER INTRUSION": 1,
};

function scoreSeverity(text) {
  const upper = (text || "").toUpperCase();
  let score = 0;
  for (const [kw, weight] of Object.entries(SEVERITY_WEIGHTS)) {
    if (upper.includes(kw)) score += weight;
  }
  if (score >= 6) return "critical";
  if (score >= 3) return "high";
  if (score >= 1) return "medium";
  return "low";
}

function extractTags(text, chapter) {
  const upper = (text || "").toUpperCase();
  const tags = [];

  // Keyword-based tags
  if (upper.includes("MOLD"))                         tags.push("mold");
  if (upper.includes("RODENT") || upper.includes("RAT") || upper.includes("MICE")) tags.push("rats/mice");
  if (upper.includes("ROACH") || upper.includes("COCKROACH")) tags.push("roaches");
  if (upper.includes("BED BUG") || upper.includes("BEDBUG")) tags.push("bed bugs");
  if (upper.includes("INFESTATION") || upper.includes("PEST")) tags.push("infestation");
  if (upper.includes("HEAT"))                         tags.push("no heat");
  if (upper.includes("HOT WATER") || upper.includes("PLUMBING")) tags.push("no hot water");
  if (upper.includes("SEWAGE") || upper.includes("SEWER")) tags.push("sewage");
  if (upper.includes("FLOOD") || upper.includes("WATER INTRUSION") || upper.includes("LEAK")) tags.push("flooding");
  if (upper.includes("STRUCTURAL") || upper.includes("UNSAFE")) tags.push("unsafe structure");
  if (upper.includes("FIRE") || upper.includes("SMOKE DETECTOR")) tags.push("fire hazard");
  if (upper.includes("ELECTRICAL"))                  tags.push("electrical");
  if (upper.includes("UNINHABITABLE") || upper.includes("UNFIT")) tags.push("uninhabitable");

  // Chapter-based tags
  const chapterTags = CHAPTER_TAGS[String(chapter)] || ["code violation"];
  for (const t of chapterTags) {
    if (!tags.includes(t)) tags.push(t);
  }

  return tags.slice(0, 6);
}

// Build a WHERE clause that matches any housing keyword
function buildWhereClause(daysBack = 730) {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - daysBack);
  const cutoffStr = cutoff.toISOString().split("T")[0] + "T00:00:00.000";

  const keywordClauses = HOUSING_KEYWORDS.map(
    (kw) => `upper(short_description) like '%${kw}%' OR upper(ordinance_text) like '%${kw}%'`
  ).join(" OR ");

  return `(${keywordClauses}) AND date_found >= '${cutoffStr}'`;
}

async function scrapeKCViolations() {
  const params = {
    "$where": buildWhereClause(730),  // last 2 years
    "$limit": 1000,
    "$order": "date_found DESC",
  };

  const response = await axios.get(SOCRATA_BASE, { params, timeout: 20000 });
  const records = response.data;

  if (!Array.isArray(records)) throw new Error("Unexpected KC Open Data response format");

  // Group violations by address so multiple violations at same property are merged
  const byAddress = {};

  for (const r of records) {
    const addr = (r.full_address || r.street_address || "").trim();
    if (!addr) continue;

    const key = addr.toUpperCase();
    if (!byAddress[key]) {
      byAddress[key] = {
        address: addr,
        violations: [],
      };
    }
    byAddress[key].violations.push(r);
  }

  // Convert grouped violations into complaint-style records
  const results = [];

  for (const [, group] of Object.entries(byAddress)) {
    const violations = group.violations;
    const latest = violations[0]; // already sorted by date_found DESC

    // Combine all text for scoring
    const allText = violations
      .map((v) => `${v.short_description || ""} ${v.ordinance_text || ""} ${v.corrective_action || ""}`)
      .join(" ");

    const tags = extractTags(allText, latest.chapter);
    const severity = scoreSeverity(allText);

    // Build a readable summary of all violations at this address
    const violationSummary = violations
      .slice(0, 5)
      .map((v) => {
        const date = v.date_found ? v.date_found.split("T")[0] : "unknown date";
        const desc = v.short_description || v.ordinance_text || "Code violation";
        const status = v.violation_status || v.case_status || "";
        return `[${date}] ${desc}${status ? ` (${status})` : ""}`;
      })
      .join("\n");

    const totalCount = violations.length;
    const openCount  = violations.filter(
      (v) => (v.violation_status || v.case_status || "").toLowerCase().includes("open") ||
              (v.violation_status || v.case_status || "").toLowerCase().includes("compliance")
    ).length;

    results.push({
      id: `kc_${latest.violation_id || latest.case_number}`,
      source: "kcdata",
      platform: "KC Open Data — Property Violations (EnerGov)",
      date: latest.date_found ? latest.date_found.split("T")[0] : new Date().toISOString().split("T")[0],
      complex: latest.full_address || latest.street_address || "Unknown address",
      address: group.address,
      managementCompany: "Unknown — check Jackson County assessor",
      managementWebsite: null,
      totalUnits: null,     // not in this dataset; HUD verify can fill this
      yearBuilt: null,
      section8Status: "unverified",
      hudMatch: null,
      tags,
      severity,
      text: `${totalCount} violation${totalCount > 1 ? "s" : ""} recorded at this address${openCount > 0 ? ` (${openCount} open)` : ""}.\n\n${violationSummary}`,
      contact: `Case #${latest.case_number || latest.violation_id} — KC Open Data`,
      // Deep-link to CompassKC for this address
      url: `https://compasskc.kcmo.org/EnerGov_Prod/SelfService#/home`,
      caseNumbers: violations.map((v) => v.case_number).filter(Boolean),
      violationCount: totalCount,
      openViolationCount: openCount,
      potentialContacts: Math.min(Math.ceil(totalCount * 1.5), 25),
      rawViolations: violations.slice(0, 10), // keep first 10 for detail panel
    });
  }

  // Sort by severity then date
  const order = { critical: 0, high: 1, medium: 2, low: 3 };
  results.sort((a, b) =>
    (order[a.severity] ?? 4) - (order[b.severity] ?? 4) ||
    (b.date || "").localeCompare(a.date || "")
  );

  return results;
}

module.exports = { scrapeKCViolations };
