// server.js — KC Housing Intel Backend v2
// Data sources: KC Open Data (property violations) + HUD Multifamily database
// Both are fully public — no API keys required

require("dotenv").config();

const express             = require("express");
const cors                = require("cors");
const { scrapeKCViolations }                              = require("./scrapers/kcViolations");
const { fetchKCHudProperties, verifyHudStatus, hudPropertiesAsLeads } = require("./scrapers/hud");

const app  = express();
const PORT = process.env.PORT || 3001;

// ── CORS ──────────────────────────────────────────────────────────────────────
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || "*" }));
app.use(express.json());

// ── In-memory cache (15 min TTL) ──────────────────────────────────────────────
const cache = {
  kcViolations:  { data: null, fetchedAt: null },
  hudProperties: { data: null, fetchedAt: null },
};
const CACHE_TTL = 15 * 60 * 1000;
const isFresh = (e) => e.data && e.fetchedAt && (Date.now() - e.fetchedAt < CACHE_TTL);

// ── GET /health ───────────────────────────────────────────────────────────────
app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    time: new Date().toISOString(),
    version: "2.0.0",
    sources: {
      kcViolations: "KC Open Data EnerGov — no key required",
      hud:          "HUD ArcGIS Multifamily — no key required",
    },
    cache: {
      kcViolations:  isFresh(cache.kcViolations)  ? `fresh (${cache.kcViolations.data?.length} records)` : "stale",
      hudProperties: isFresh(cache.hudProperties) ? `fresh (${cache.hudProperties.data?.length} records)` : "stale",
    },
  });
});

// ── GET /api/scan ─────────────────────────────────────────────────────────────
// Merges KC property violations + HUD properties into one complaint feed
// ?sources=kcdata,hud  (default: both)
// ?fresh=true          (bypass cache)
app.get("/api/scan", async (req, res) => {
  const sources    = (req.query.sources || "kcdata,hud").split(",");
  const forceFresh = req.query.fresh === "true";
  const results    = [];
  const errors     = [];

  // ── KC Open Data violations ────────────────────────────────────────────────
  if (sources.includes("kcdata")) {
    try {
      if (!forceFresh && isFresh(cache.kcViolations)) {
        console.log("KC Violations: cache hit");
        results.push(...cache.kcViolations.data);
      } else {
        console.log("KC Violations: fetching live…");
        const data = await scrapeKCViolations();
        cache.kcViolations = { data, fetchedAt: Date.now() };
        results.push(...data);
        console.log(`KC Violations: ${data.length} records`);
      }
    } catch (err) {
      console.error("KC Violations error:", err.message);
      errors.push({ source: "kcdata", error: err.message });
    }
  }

  // ── HUD properties ────────────────────────────────────────────────────────
  if (sources.includes("hud")) {
    try {
      let hudProps;
      if (!forceFresh && isFresh(cache.hudProperties)) {
        console.log("HUD: cache hit");
        hudProps = cache.hudProperties.data;
      } else {
        console.log("HUD: fetching live…");
        hudProps = await fetchKCHudProperties();
        cache.hudProperties = { data: hudProps, fetchedAt: Date.now() };
        console.log(`HUD: ${hudProps.length} properties`);
      }
      results.push(...await hudPropertiesAsLeads(hudProps));
    } catch (err) {
      console.error("HUD error:", err.message);
      errors.push({ source: "hud", error: err.message });
    }
  }

  // Sort: severity order, then date descending
  const order = { critical: 0, high: 1, medium: 2, low: 3 };
  results.sort((a, b) =>
    (order[a.severity] ?? 4) - (order[b.severity] ?? 4) ||
    (b.date || "").localeCompare(a.date || "")
  );

  res.json({
    success: true,
    count: results.length,
    fetchedAt: new Date().toISOString(),
    errors: errors.length ? errors : undefined,
    results,
  });
});

// ── POST /api/verify-hud ──────────────────────────────────────────────────────
app.post("/api/verify-hud", async (req, res) => {
  const { address, complexName } = req.body;
  if (!address) return res.status(400).json({ error: "address is required" });

  try {
    let hudProps = isFresh(cache.hudProperties)
      ? cache.hudProperties.data
      : await fetchKCHudProperties();
    if (!isFresh(cache.hudProperties)) {
      cache.hudProperties = { data: hudProps, fetchedAt: Date.now() };
    }
    const result = await verifyHudStatus(address, complexName || "", hudProps);
    res.json({ success: true, ...result });
  } catch (err) {
    console.error("HUD verify error:", err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET /api/hud-properties ───────────────────────────────────────────────────
app.get("/api/hud-properties", async (req, res) => {
  try {
    let props = isFresh(cache.hudProperties)
      ? cache.hudProperties.data
      : await fetchKCHudProperties();
    if (!isFresh(cache.hudProperties)) {
      cache.hudProperties = { data: props, fetchedAt: Date.now() };
    }
    res.json({ success: true, count: props.length, properties: props });
  } catch (err) {
    console.error("HUD properties error:", err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET /api/violations ───────────────────────────────────────────────────────
// Raw KC violations (useful for debugging / building your own queries)
app.get("/api/violations", async (req, res) => {
  try {
    let data = isFresh(cache.kcViolations)
      ? cache.kcViolations.data
      : await scrapeKCViolations();
    if (!isFresh(cache.kcViolations)) {
      cache.kcViolations = { data, fetchedAt: Date.now() };
    }
    res.json({ success: true, count: data.length, violations: data });
  } catch (err) {
    console.error("KC Violations error:", err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════╗
║   KC Housing Intel — Backend v2.0              ║
║   Port: ${PORT}                                   ║
║                                                ║
║   Data sources (no API keys required):         ║
║   • KC Open Data — EnerGov property violations ║
║   • HUD Multifamily ArcGIS database            ║
║                                                ║
║   Routes:                                      ║
║   GET  /health                                 ║
║   GET  /api/scan                               ║
║   GET  /api/violations                         ║
║   GET  /api/hud-properties                     ║
║   POST /api/verify-hud                         ║
╚════════════════════════════════════════════════╝
  `);
});
